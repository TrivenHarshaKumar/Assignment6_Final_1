﻿
// Adjunct.cs
//
// Huimin Zhao
// 
// Adjunct class that extends Employee.
using System;

[Serializable]
public class Adjunct : Employee
{
    // private instance variable for storing weekly salary
    private decimal weeklySalaryValue;

    // parameter-less constructor
    public Adjunct() : base()
    {
    }

    // constructor
    public Adjunct(string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone, decimal weeklySalary)
        : base(first, last, married, gender, birthDate, homeAddress, homePhone, cellPhone)
    {
        this.WeeklySalary = weeklySalary;
    } // end SalariedEmployee constructor

    // property that gets and sets salaried employee's salary
    public decimal WeeklySalary
    {
        get
        {
            return weeklySalaryValue;
        } // end get
        set
        {
            if (value < 0)
                throw new ApplicationException("Salary must not be negative!");
            weeklySalaryValue = value;
        } // end set
    } // end property WeeklySalary

    // return string representation of SalariedEmployee object
    // calculate earnings; override Employee's abstract property Earnings 
    public override decimal Earnings
    {
        get
        {
            return WeeklySalary;
        }
    } // end property Earnings

    // override Employee's abstract property Category 
    public override string Category
    {
        get
        {
            return "Salaried";
        }
    } // end property Category

    // override Employee's abstract property EmployeeType 
    public override string EmployeeType
    {
        get
        {
            return "Adjunct";
        }
    } // end property Category


    
    // override Employee's abstract property RetirementPercentage 
    public override double RetirementPercentage
    {
        get
        {
            return 0;
        }
    } // end property RetirementPercentage

    // returns string representation of Employee object
    public override string ToString()
    {
        string result = Name + "\t"
        + EmployeeType + ", Salary: " + Salary.ToString("C")
        + ", Retirement: " + Retirement.ToString("C")
        + "(" + RetirementPercentage + "%), TSA: "
        + TSA.ToString("C") + ", Taxable Income: "
        + TaxableIncome.ToString("C")
        + ", TAX: " + TaxWithheld.ToString("C") + "(" + TaxWithholdingPercentage + "%), Health Insurance: "
        + HealthInsuranceAmount.ToString("C") + ", NetPay: "
        + NetPay.ToString("C") + ". " + HomeAddress + ". " + HomePhone + "/" + CellPhone + ". Contract till "+ContractDate.ToString("MM/dd/yyyy");


        return result;
    } // end method ToString


} // end class SalariedEmployee

