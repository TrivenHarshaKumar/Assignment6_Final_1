// Employee.cs
//
// Huimin Zhao
// 
// Employee abstract base class.

using System;

[Serializable]
public abstract class Employee
{
    // private instance variable for storing first name
    private string firstNameValue;

    // private instance variable for storing last name
    private string lastNameValue;

    // private instance variable for storing birth date
    private DateTime birthDateValue;

    // private instance variable for storing Contract date
    private DateTime ContractDateValue;

    // private instance variable for storing Salary
    private decimal SalaryValue;

    // private instance variable for storing TSA
    private decimal TSAValue;

    // parameter-less constructor
    public Employee()
    {
    }

   // constructor
   public Employee( string first, string last, bool married, string gender, DateTime birthDate, Address homeAddress, PhoneNumber homePhone, PhoneNumber cellPhone)
   {
      this.FirstName = first;
      this.LastName = last;
      this.Married = married;
      this.Gender = gender;
      this.BirthDate = birthDate;
      this.HomeAddress = homeAddress;
      this.HomePhone = homePhone;
      this.CellPhone = cellPhone;
   } // end Employee constructor

   // property to get and set employee's first name
   public string FirstName
   {
      get
      {
          return Util.Capitalize(firstNameValue);
      } // end get
      set
      {
          value = value.Trim().ToUpper();
          if (value.Length < 1)
              throw new ApplicationException("First name is empty!");
          // check for letters
          foreach(char c in value)
              if(c<'A' || c>'Z')
                  throw new ApplicationException("First name must consist of letters only!");
          firstNameValue = value;
      } // end set
   } // end property FirstName

   // property to get and set employee's last name
   public string LastName
   {
      get
      {
          return Util.Capitalize(lastNameValue);
      } // end get
      set
      {
          value = value.Trim().ToUpper();
          if (value.Length < 1)
              throw new ApplicationException("Last name is empty!");
          // check for letters
          foreach (char c in value)
              if (c < 'A' || c > 'Z')
                  throw new ApplicationException("Last name must consist of letters only!");
          lastNameValue = value;
      } // end set
   } // end property LastName

   // read-only property to get employee's name
   public string Name
   {
       get
       {
           return LastName + ", " + FirstName;
       } // end get
   } // end property Name

   // property to get and set whether employee is married
   public bool Married {get; set;}

   // read-only property to get employee's marital status
   public string MaritalStatus
   {
       get
       {
           if (Married)
               return "married";
           else
               return "single";
       } // end get
   } // end property Name

    // property to get and set whether employee is married
    public string MarriageStatus { get; set; }

    public string AcademicDegree { get; set; }

    public bool Tenured { get; set; }

    // property to get and set whether employee is HealthInsurance
    public string HealthInsurance { get; set; }

    // property to get and set whether employee is male
    public bool IsMale {get; set;}

   // property to get and set whether employee is female
   public bool IsFemale
   {
      get
      {
         return !IsMale;
      } // end get
      set
      {
          IsMale = !value;
      } // end set
   } // end property IsFemale

   // property to get and set employee's gender
   public string Gender
   {
      get
      {
          if(IsMale)
              return "Male";
          else
              return "Female";
      } // end get
      set
      {
          value = value.ToUpper();
          if (value == "MALE" || value == "M")
              IsMale = true;
          else if (value == "FEMALE" || value == "F")
              IsMale = false;
          else
              throw new ApplicationException("Gender should be Male or Female!");
      } // end set
   } // end property Gender

  

    // property to get and set employee's birth date
   public DateTime BirthDate
   {
      get
      {
          return birthDateValue;
      } // end get
      set
      {
          if(value > DateTime.Now)
          {
              throw new ApplicationException("Employee birth date must be prior to today!");
          }
          birthDateValue = value;
      } // end set
  } // end property BirthDate

    public DateTime ContractDate
    {
        get
        {
            return ContractDateValue;
        } // end get
        set
        {
           
            ContractDateValue = value;
        } // end set
    } // end property ContractDate

    // read-only property to get employee's age
    public byte Age
  {
      get
      {
          // Get the birth date value for the current year.

          DateTime thisYearBirthDate = new DateTime(DateTime.Now.Year, BirthDate.Month, BirthDate.Day);

          // Calculate and return the age based on if the birth date has occurred this year or not.

          if (thisYearBirthDate <= DateTime.Now)
          {
              return (byte)(DateTime.Now.Year - BirthDate.Year);
          }
          else
          {
              return (byte)(DateTime.Now.Year - BirthDate.Year - 1);
          }
      }
  }

  // property to get and set employee's home address
  public Address HomeAddress { get; set; }

  // property to get and set employee's home phone
  public PhoneNumber HomePhone { get; set; }

  // property to get and set employee's cell phone
  public PhoneNumber CellPhone { get; set; }

   // returns string representation of Employee object
 
   // virtual readonly property for Category, will be overridden by derived classes
   public virtual string Category
   {
       get
       {
           return "Employee";
       }
   } // no implementation here

    public virtual string EmployeeType
    {
        get
        {
            return "Employee";
        }
    } // no implementation here


    // abstract readonly property for earnings, will be overridden by derived classes
    public abstract decimal Earnings
   {
       get;
   } // no implementation here

   //  readonly property for TaxWithholdingPercentage
   public double TaxWithholdingPercentage
   {
        get
        {
            if (MarriageStatus.Equals("Single"))
                return 20;
            else if (MarriageStatus.Equals("Married, No Child"))
                return 18;
            else
                return 15;
        }
    } 

   // read-only property to get employee's TaxWithheld
   public decimal TaxWithheld
   {
       get
       {
           return TaxableIncome * (decimal)TaxWithholdingPercentage / 100;
       }
   }

    public decimal Salary
    {
        get
        {
            return SalaryValue;
        } // end get
        set
        {
            if (value < 0)
                throw new ApplicationException("Salary must not be negative!");
            SalaryValue = value;
        } // end set
    }

    // abstract readonly property for RetirementPercentage, will be overridden by derived classes
    public abstract double RetirementPercentage
    {
        get;
    }

    public decimal Retirement
    {
        get
        {
            return Salary * (decimal)RetirementPercentage / 100;
        }
    }// no implementation here

    public decimal TSA
    {
        get
        {
            return TSAValue;
        } // end get
        set
        {
            if (value < 0 || value>1500)
                throw new ApplicationException("TSA must be between $0 and $1500!");
            TSAValue = value;
        } // end set
    }

    public decimal TaxableIncome
    {
        get
        {

            return Salary - Retirement - TSA;
        }
    }

    public decimal HealthInsuranceAmount
    {
        get
        {
            if (HealthInsurance.Equals("State"))
                return (decimal)150;
            else if (HealthInsurance.Equals("Humana"))
                return (decimal)230;
            else
                return (decimal)0;
        } // end get
       
    }

    public decimal NetPay
    {
        get
        {

            return TaxableIncome - HealthInsuranceAmount - TaxWithheld;
        }
    }
} // end abstract class Employee
